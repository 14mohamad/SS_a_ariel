import java.util.Stack;

public class GameLogic implements PlayableLogic {
    private static final int BOARD_SIZE = 11;
    private static final int[][] CORNER_POSITIONS = {{0, 0}, {0, 10}, {10, 0}, {10, 10}};
    private ConcretePlayer firstPlayer, secondPlayer, currentPlayer;
    private ConcretePiece[][] board;
    private final Stack<Move> moveHistory = new Stack<>();

    public GameLogic() {
        initializePlayersAndBoard();
        initializeBoard();
    }

    private void initializePlayersAndBoard() {
        firstPlayer = new ConcretePlayer(true);
        secondPlayer = new ConcretePlayer(false);
        currentPlayer = secondPlayer;
        board = new ConcretePiece[BOARD_SIZE][BOARD_SIZE];
    }

    private void initializeBoard()
    {
        // Places 13 bright parts
        board[5][3] = new Pawn(firstPlayer);  // D1
        board[4][4] = new Pawn(firstPlayer);  // D2
        board[5][4] = new Pawn(firstPlayer);  // D3
        board[6][4] = new Pawn(firstPlayer);  // D4
        board[3][5] = new Pawn(firstPlayer);  // D5
        board[4][5] = new Pawn(firstPlayer);  // D6
        board[5][5] = new King(firstPlayer);  // D7 (King)
        board[6][5] = new Pawn(firstPlayer);  // D8
        board[7][5] = new Pawn(firstPlayer);  // D9
        board[4][6] = new Pawn(firstPlayer);  // D10
        board[5][6] = new Pawn(firstPlayer);  // D11
        board[6][6] = new Pawn(firstPlayer);  // D12
        board[5][7] = new Pawn(firstPlayer);  // D13


        // Places 24 dark parts
        board[3][0] = new Pawn(secondPlayer);  // A1
        board[4][0] = new Pawn(secondPlayer);  // A2
        board[5][0] = new Pawn(secondPlayer);  // A3
        board[6][0] = new Pawn(secondPlayer);  // A4
        board[7][0] = new Pawn(secondPlayer);  // A5
        board[5][1] = new Pawn(secondPlayer);  // A6
        board[0][3] = new Pawn(secondPlayer);  // A7
        board[10][3] = new Pawn(secondPlayer); // A8
        board[0][4] = new Pawn(secondPlayer);  // A9
        board[10][4] = new Pawn(secondPlayer); // A10
        board[0][5] = new Pawn(secondPlayer);  // A11
        board[1][5] = new Pawn(secondPlayer);  // A12
        board[9][5] = new Pawn(secondPlayer);  // A13
        board[10][5] = new Pawn(secondPlayer); // A14
        board[0][6] = new Pawn(secondPlayer);  // A15
        board[10][6] = new Pawn(secondPlayer); // A16
        board[0][7] = new Pawn(secondPlayer);  // A17
        board[10][7] = new Pawn(secondPlayer); // A18
        board[5][9] = new Pawn(secondPlayer);  // A19
        board[3][10] = new Pawn(secondPlayer); // A20
        board[4][10] = new Pawn(secondPlayer); // A21
        board[5][10] = new Pawn(secondPlayer); // A22
        board[6][10] = new Pawn(secondPlayer); // A23
        board[7][10] = new Pawn(secondPlayer); // A24

    }


    @Override
    public boolean move(Position a, Position b) {
        ConcretePiece piece = board[a.getRow()][a.getCol()];
        if (piece == null || piece.getOwner() != currentPlayer || !isValidMove(a, b))
            return false;

        System.out.println("Moving from: (" + (a.getRow() ) + ", " + (a.getCol() ) + ")");
        System.out.println("Moving to  : (" + (b.getRow() ) + ", " + (b.getCol()) + ")");

        moveHistory.push(new Move(a, b, piece));
        board[b.getRow()][b.getCol()] = piece;
        board[a.getRow()][a.getCol()] = null;
        currentPlayer =  isSecondPlayerTurn() ?firstPlayer: secondPlayer ;
        return true;
    }

    private boolean isValidMove(Position a, Position b) {
        if (!isValidPosition(a) || !isValidPosition(b))
            return false;

        ConcretePiece piece = board[a.getRow()][a.getCol()];
        if (piece == null || piece.getOwner() != currentPlayer)
            return false;

        int rowDiff = Math.abs(a.getRow() - b.getRow());
        int colDiff = Math.abs(a.getCol() - b.getCol());
        if (rowDiff != 0 && colDiff != 0)
            return false;

        // Check if the destination position is empty
        if (board[b.getRow()][b.getCol()] != null) {
            return false;
        }

        // Check if there is a piece in the way
        if (rowDiff == 0) {
            int minCol = Math.min(a.getCol(), b.getCol());
            int maxCol = Math.max(a.getCol(), b.getCol());
            for (int col = minCol + 1; col < maxCol; col++) {
                if (board[a.getRow()][col] != null) {
                    return false;
                }
            }
        } else {
            int minRow = Math.min(a.getRow(), b.getRow());
            int maxRow = Math.max(a.getRow(), b.getRow());
            for (int row = minRow + 1; row < maxRow; row++) {
                if (board[row][a.getCol()] != null) {
                    return false;
                }
            }
        }

        // Check if the destination position is one of the corner positions
        for (int[] corner : CORNER_POSITIONS) {
            if (b.getRow() == corner[0] && b.getCol() == corner[1]) {
                // Only allow the king to go and stand in corner positions
                return piece instanceof King;
            }
        }

        return true;
    }


    private boolean isValidPosition(Position position) {
        int row = position.getRow();
        int col = position.getCol();
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }


    @Override
    public Piece getPieceAtPosition(Position position) {
        return board[position.getRow()][position.getCol()];
    }

    @Override
    public Player getFirstPlayer() {
        return firstPlayer;
    }

    @Override
    public Player getSecondPlayer() {
        return secondPlayer;
    }

    @Override
    public boolean isGameFinished() {
        // Check if the king has reached one of the corner positions
        for (int[] corner : CORNER_POSITIONS) {
            ConcretePiece piece = board[corner[0]][corner[1]];
            if (piece instanceof King) {
                firstPlayer.incrementWins();
                return true;  // King reached a corner, game over
            }
        }

        return false;  // King not found in corner positions, game continues
    }

    @Override
    public boolean isSecondPlayerTurn() {
        return currentPlayer == secondPlayer;
    }

    @Override
    public void reset() {
        // Clear move history
        moveHistory.clear();

        initializePlayersAndBoard();

        // Place pieces on the board
        initializeBoard();
    }


    @Override
    public void undoLastMove() {
        if (!moveHistory.isEmpty()) {
            Move lastMove = moveHistory.pop();
            Position from = lastMove.getFrom();
            Position to = lastMove.getTo();
            ConcretePiece piece = lastMove.getPiece();

            // Move the piece back to the original position
            board[from.getRow()][from.getCol()] = piece;
            board[to.getRow()][to.getCol()] = null;

            // Switch back to the previous player
            currentPlayer = (currentPlayer == firstPlayer) ? secondPlayer : firstPlayer;
        }
    }

    @Override
    public int getBoardSize() {
        return BOARD_SIZE;
    }

    // Inner class to represent a move
    private static class Move {
        private final Position from;
        private final Position to;
        private ConcretePiece piece;

        public Move(Position from, Position to, ConcretePiece piece) {
            this.from = from;
            this.to = to;
            this.piece = piece;
        }

        public Position getFrom() {
            return from;
        }

        public Position getTo() {
            return to;
        }

        public ConcretePiece getPiece() {
            return piece;
        }
    }
}