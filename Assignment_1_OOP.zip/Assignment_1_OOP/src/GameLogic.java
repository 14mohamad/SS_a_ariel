import java.util.Stack;

public class GameLogic implements PlayableLogic {
    private static final int BOARD_SIZE = 11;
    private static final int[][] CORNER_POSITIONS = {{0, 0}, {0, 10}, {10, 0}, {10, 10}};
    private ConcretePlayer firstPlayer, secondPlayer, currentPlayer;
    private ConcretePiece[][] board;
    private final Stack<Move> moveHistory = new Stack<>();

    public GameLogic() {
        initializePlayersAndBoard();
        initializeBoard();
    }

    private void initializePlayersAndBoard() {
        firstPlayer = new ConcretePlayer(true);
        secondPlayer = new ConcretePlayer(false);
        currentPlayer = secondPlayer;
        board = new ConcretePiece[BOARD_SIZE][BOARD_SIZE];
    }

    private void initializeBoard() {
        // Places 13 bright parts
        board[5][3] = new Pawn(firstPlayer);  // D1
        board[4][4] = new Pawn(firstPlayer);  // D2
        board[5][4] = new Pawn(firstPlayer);  // D3
        board[6][4] = new Pawn(firstPlayer);  // D4
        board[3][5] = new Pawn(firstPlayer);  // D5
        board[4][5] = new Pawn(firstPlayer);  // D6
        board[5][5] = new King(firstPlayer);  // D7 (King)
        board[6][5] = new Pawn(firstPlayer);  // D8
        board[7][5] = new Pawn(firstPlayer);  // D9
        board[4][6] = new Pawn(firstPlayer);  // D10
        board[5][6] = new Pawn(firstPlayer);  // D11
        board[6][6] = new Pawn(firstPlayer);  // D12
        board[5][7] = new Pawn(firstPlayer);  // D13


        // Places 24 dark parts
        board[3][0] = new Pawn(secondPlayer);  // A1
        board[4][0] = new Pawn(secondPlayer);  // A2
        board[5][0] = new Pawn(secondPlayer);  // A3
        board[6][0] = new Pawn(secondPlayer);  // A4
        board[7][0] = new Pawn(secondPlayer);  // A5
        board[5][1] = new Pawn(secondPlayer);  // A6
        board[0][3] = new Pawn(secondPlayer);  // A7
        board[10][3] = new Pawn(secondPlayer); // A8
        board[0][4] = new Pawn(secondPlayer);  // A9
        board[10][4] = new Pawn(secondPlayer); // A10
        board[0][5] = new Pawn(secondPlayer);  // A11
        board[1][5] = new Pawn(secondPlayer);  // A12
        board[9][5] = new Pawn(secondPlayer);  // A13
        board[10][5] = new Pawn(secondPlayer); // A14
        board[0][6] = new Pawn(secondPlayer);  // A15
        board[10][6] = new Pawn(secondPlayer); // A16
        board[0][7] = new Pawn(secondPlayer);  // A17
        board[10][7] = new Pawn(secondPlayer); // A18
        board[5][9] = new Pawn(secondPlayer);  // A19
        board[3][10] = new Pawn(secondPlayer); // A20
        board[4][10] = new Pawn(secondPlayer); // A21
        board[5][10] = new Pawn(secondPlayer); // A22
        board[6][10] = new Pawn(secondPlayer); // A23
        board[7][10] = new Pawn(secondPlayer); // A24

    }


    @Override
    public boolean move(Position a, Position b) {
        ConcretePiece piece = board[a.getCol()][a.getRow()];
        if (piece == null || piece.getOwner() != currentPlayer || !isValidMove(a, b))
            return false;
        // System.out.println(a.getRow());
        System.out.println("a.getRow() = " + a.getRow() + " ,a.getCol() = " + a.getCol());
        System.out.println("b.getRow() = " + b.getRow() + " ,b.getCol() = " + b.getCol());

        moveHistory.push(new Move(a, b, piece));
        board[b.getCol()][b.getRow()] = piece;
        board[a.getCol()][a.getRow()] = null;
        //TODO scan for possible kill of enemy soldier or king perhaps
        enemyScanAndKill(piece, b);
        currentPlayer = isSecondPlayerTurn() ? firstPlayer : secondPlayer;
        return true;
    }

    private void enemyScanAndKill(ConcretePiece concretePiece, Position p) {
        /**
         * TODO we need to keep in mind , the gui somehow treats cols before rows board[i][j] means col i row j
         *
         */
        /**
         * we will have to look for all the possible scenarios of killing an enemy soldier
         * 1)
         * 2)
         * 3)
         * 4)
         */
        if(!(concretePiece instanceof King)) {
            int j = p.getCol();
            int i = p.getRow();
            ///TODO if instance of pawn , since king doesnt have the ability to participate in killing an enemy
            // we begin with checking for nearby pieces and we ask them to identify (lets hope not as a cat)
            Piece up = this.getPieceAtPosition(new Position(j, i - 1));
            Piece down = this.getPieceAtPosition(new Position(j, i + 1));
            Piece left = this.getPieceAtPosition(new Position(j - 1, i));
            Piece right = this.getPieceAtPosition(new Position(j + 1, i));
            //checking each side for an enemy soldier or an enemy king
            check_up(up, j, i);
            check_down(down, j, i);
            check_left(left, j, i);
            check_right(right, j, i);
            //TODO check the checks for typing errors cause they are a bit complicated .

        }
        // if a king he cant attack whatsoever
        return;
    }

    private void check_right(Piece right, int j, int i) {
        if (right != null && right.getOwner() != this.currentPlayer) {
            /// it's not null and the owner is the other player , means enemy soldier we proceed to check for upup if it's our soldier
            if (!(right instanceof King)) {
                Piece right_right = getPieceAtPosition(new Position(j+2, i)); // returns null in 2 cases 1.out of bounds 2.no piece
                if ((right_right != null && right_right.getOwner() == this.currentPlayer) || (j + 2 == BOARD_SIZE) || (is_corner(j+2, i))) {
                    // Ladies and gentlemen es hora de comer
                    board[j+1][i] = null;
                }

            } else {
                // TODO IS A KING !! 👑
                Piece right_right = getPieceAtPosition(new Position(j+2, i));
                Piece right_up = getPieceAtPosition(new Position(j + 1, i - 1));
                Piece right_down = getPieceAtPosition(new Position(j + 1, i + 1));
                if ((right_right != null && right_right.getOwner() == this.currentPlayer) && (right_up != null && right_up.getOwner() == this.currentPlayer)
                        && (right_down != null && right_down.getOwner() == this.currentPlayer)) {
                    // if all exist and are friendly soldiers , kill the king bro ...
                    board[j+1][i] = null;
                    // TODO end the game

                } else if ((j + 2 == BOARD_SIZE) && (right_up != null && right_up.getOwner() == this.currentPlayer)
                        && (right_down != null && right_down.getOwner() == this.currentPlayer)) {
                    board[j+1][i] = null;
                    // TODO end the game

                } else if ((right_right != null && right_right.getOwner() == this.currentPlayer) && (right_up != null && right_up.getOwner() == this.currentPlayer)
                        && (i + 1 == BOARD_SIZE)) {
                    board[j+1][i] = null;
                    // TODO end the game

                } else if ((right_right != null && right_right.getOwner() == this.currentPlayer) && (i - 1 == -1)
                        && (right_down != null && right_down.getOwner() == this.currentPlayer)) {

                    board[j+1][i] = null;
                    // TODO end the game
                }
            }
        }

    }

    private void check_left(Piece left, int j, int i) {
        if (left != null && left.getOwner() != this.currentPlayer) {
            /// it's not null and the owner is the other player , means enemy soldier we proceed to check for upup if it's our soldier
            if (!(left instanceof King)) {
                Piece left_left = getPieceAtPosition(new Position(j-2, i)); // returns null in 2 cases 1.out of bounds 2.no piece
                if ((left_left != null && left_left.getOwner() == this.currentPlayer) || (j - 2 == -1) || (is_corner(j-2, i))) {
                    // Ladies and gentlemen es hora de comer
                    board[j-1][i] = null;
                }

            } else {
                // TODO IS A KING !! 👑
                Piece left_left = getPieceAtPosition(new Position(j-2, i));
                Piece left_up = getPieceAtPosition(new Position(j - 1, i - 1));
                Piece left_down = getPieceAtPosition(new Position(j - 1, i + 1));
                if ((left_left != null && left_left.getOwner() == this.currentPlayer) && (left_up != null && left_up.getOwner() == this.currentPlayer)
                        && (left_down != null && left_down.getOwner() == this.currentPlayer)) {
                    // if all exist and are friendly soldiers , kill the king bro ...
                    board[j-1][i] = null;
                    // TODO end the game

                } else if ((j - 2 == -1) && (left_up != null && left_up.getOwner() == this.currentPlayer)
                        && (left_down != null && left_down.getOwner() == this.currentPlayer)) {
                    board[j-1][i] = null;
                    // TODO end the game

                } else if ((left_left != null && left_left.getOwner() == this.currentPlayer) && (left_up != null && left_up.getOwner() == this.currentPlayer)
                        && (i + 1 == BOARD_SIZE)) {
                    board[j-1][i] = null;
                    // TODO end the game

                } else if ((left_left != null && left_left.getOwner() == this.currentPlayer) && (i - 1 == -1)
                        && (left_down != null && left_down.getOwner() == this.currentPlayer)) {

                    board[j-1][i] = null;
                    // TODO end the game
                }
            }
        }

    }

    private void check_down(Piece down, int j, int i) {
        if (down != null && down.getOwner() != this.currentPlayer) {
            /// it's not null and the owner is the other player , means enemy soldier we proceed to check for upup if it's our soldier
            if (!(down instanceof King)) {
                Piece down_down = getPieceAtPosition(new Position(j, i + 2)); // returns null in 2 cases 1.out of bounds 2.no piece
                if ((down_down != null && down_down.getOwner() == this.currentPlayer) || (i + 2 == BOARD_SIZE) || (is_corner(j, i + 2))) {
                    // Ladies and gentlemen es hora de comer
                    board[j][i + 1] = null;
                }

            } else {
                // TODO IS A KING !! 👑
                Piece down_down = getPieceAtPosition(new Position(j, i + 2));
                Piece down_left = getPieceAtPosition(new Position(j - 1, i + 1));
                Piece down_right = getPieceAtPosition(new Position(j + 1, i + 1));
                if ((down_down != null && down_down.getOwner() == this.currentPlayer) && (down_left != null && down_left.getOwner() == this.currentPlayer)
                        && (down_right != null && down_right.getOwner() == this.currentPlayer)) {
                    // if all exist and are friendly soldiers , kill the king bro ...
                    board[j][i + 1] = null;
                    // TODO end the game

                } else if ((i + 2 == BOARD_SIZE) && (down_left != null && down_left.getOwner() == this.currentPlayer)
                        && (down_right != null && down_right.getOwner() == this.currentPlayer)) {
                    board[j][i + 1] = null;
                    // TODO end the game

                } else if ((down_down != null && down_down.getOwner() == this.currentPlayer) && (down_left != null && down_left.getOwner() == this.currentPlayer)
                        && (j + 1 == BOARD_SIZE)) {
                    board[j][i + 1] = null;
                    // TODO end the game

                } else if ((down_down != null && down_down.getOwner() == this.currentPlayer) && (j - 1 == -1)
                        && (down_right != null && down_right.getOwner() == this.currentPlayer)) {

                    board[j][i + 1] = null;
                    // TODO end the game
                }
            }
        }

    }

    private void check_up(Piece up, int j, int i) {
        if (up != null && up.getOwner() != this.currentPlayer) {
            /// it's not null and the owner is the other player , means enemy soldier we proceed to check for upup if it's our soldier
            if (!(up instanceof King)) {
                Piece up_up = getPieceAtPosition(new Position(j, i - 2)); // returns null in 2 cases 1.out of bounds 2.no piece
                if ((up_up != null && up_up.getOwner() == this.currentPlayer) || (i - 2 == -1) || (is_corner(j, i - 2))) {
                    // Ladies and gentlemen es hora de comer
                    board[j][i - 1] = null;
                }

            } else {
                // TODO IS A KING !! 👑
                Piece up_up = getPieceAtPosition(new Position(j, i - 2));
                Piece up_left = getPieceAtPosition(new Position(j - 1, i - 1));
                Piece up_right = getPieceAtPosition(new Position(j + 1, i - 1));
                if ((up_up != null && up_up.getOwner() == this.currentPlayer) && (up_left != null && up_left.getOwner() == this.currentPlayer)
                        && (up_right != null && up_right.getOwner() == this.currentPlayer)) {
                    // if all exist and are friendly soldiers , kill the king bro ...
                    board[j][i - 1] = null;
                    // TODO end the game

                } else if ((i - 2 == -1) && (up_left != null && up_left.getOwner() == this.currentPlayer)
                        && (up_right != null && up_right.getOwner() == this.currentPlayer)) {
                    board[j][i - 1] = null;
                    // TODO end the game

                } else if ((up_up != null && up_up.getOwner() == this.currentPlayer) && (up_left != null && up_left.getOwner() == this.currentPlayer)
                        && (j + 1 == BOARD_SIZE)) {
                    board[j][i - 1] = null;
                    // TODO end the game

                } else if ((up_up != null && up_up.getOwner() == this.currentPlayer) && (j - 1 == -1)
                        && (up_right != null && up_right.getOwner() == this.currentPlayer)) {

                    board[j][i - 1] = null;
                    // TODO end the game
                }
            }
        }
    }

    private boolean is_corner(int col, int row) {
        for (int i = 0; i < CORNER_POSITIONS.length; i++) {
            if (CORNER_POSITIONS[i][0] == row && CORNER_POSITIONS[i][1] == col) {
                return true;
            }
        }
        return false;
    }

    private boolean isValidMove(Position a, Position b) {
        // if it's out of bounds then don't do anything
        if (!isValidPosition(a) || !isValidPosition(b))
            return false;

        Piece piece = getPieceAtPosition(a);
        // if it's not our piece or an empty place then don't move it
        if (piece == null || piece.getOwner() != currentPlayer)
            return false;

        // to prevent diagonal move
        int rowDiff = Math.abs(a.getRow() - b.getRow());
        int colDiff = Math.abs(a.getCol() - b.getCol());
        if (rowDiff != 0 && colDiff != 0)
            return false;

        // Check if the destination position is empty
        if (board[b.getCol()][b.getRow()] != null) {
            return false;
        }

        // Check if there is a piece in the way
        if (rowDiff == 0) { // if in same line means we're about to go horizontal lets check for any pawn in between the col_a and col_b
            int minCol = Math.min(a.getCol(), b.getCol());
            int maxCol = Math.max(a.getCol(), b.getCol());
            for (int col = minCol + 1; col < maxCol; col++) {
                if (board[col][a.getRow()] != null) {
                    return false;
                }
            }
        } else { /// means vertical we check for (min-line+1 to max-line-1 for non-null )
            int minRow = Math.min(a.getRow(), b.getRow());
            int maxRow = Math.max(a.getRow(), b.getRow());
            for (int row = minRow + 1; row < maxRow; row++) {
                if (board[a.getCol()][row] != null) {
                    return false;
                }
            }
        }
        // TODO check it doesnt intervene with the opposite coordinates
        // Check if the destination position is one of the corner positions
        for (int[] corner : CORNER_POSITIONS) {
            if (b.getRow() == corner[0] && b.getCol() == corner[1]) {
                // Only allow the king to go and stand in corner positions
                return piece instanceof King;
            }
        }

        return true;
    }


    private boolean isValidPosition(Position position) {
        int row = position.getRow();
        int col = position.getCol();
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }


    @Override
    public Piece getPieceAtPosition(Position position) {
        if (isValidPosition(position)) {
            return board[position.getCol()][position.getRow()];
        }
        return null;
    }

    @Override
    public Player getFirstPlayer() {
        return firstPlayer;
    }

    @Override
    public Player getSecondPlayer() {
        return secondPlayer;
    }

    @Override
    public boolean isGameFinished() {
        // Check if the king has reached one of the corner positions
        for (int[] corner : CORNER_POSITIONS) {
            ConcretePiece piece = board[corner[0]][corner[1]];
            if (piece instanceof King) {
                firstPlayer.incrementWins();
                return true;  // King reached a corner, game over
            }
        }

        return false;  // King not found in corner positions, game continues
    }

    @Override
    public boolean isSecondPlayerTurn() {
        return currentPlayer == secondPlayer;
    }

    @Override
    public void reset() {
        // Clear move history
        moveHistory.clear();

        initializePlayersAndBoard();

        // Place pieces on the board
        initializeBoard();
    }


    @Override
    public void undoLastMove() {
        if (!moveHistory.isEmpty()) {
            Move lastMove = moveHistory.pop();
            Position from = lastMove.getFrom();
            Position to = lastMove.getTo();
            ConcretePiece piece = lastMove.getPiece();

            // Move the piece back to the original position
            board[from.getRow()][from.getCol()] = piece;
            board[to.getRow()][to.getCol()] = null;

            // Switch back to the previous player
            currentPlayer = (currentPlayer == firstPlayer) ? secondPlayer : firstPlayer;
        }
    }

    @Override
    public int getBoardSize() {
        return BOARD_SIZE;
    }

    // Inner class to represent a move
    private static class Move {
        private final Position from;
        private final Position to;
        private ConcretePiece piece;

        public Move(Position from, Position to, ConcretePiece piece) {
            this.from = from;
            this.to = to;
            this.piece = piece;
        }

        public Position getFrom() {
            return from;
        }

        public Position getTo() {
            return to;
        }

        public ConcretePiece getPiece() {
            return piece;
        }
    }
}