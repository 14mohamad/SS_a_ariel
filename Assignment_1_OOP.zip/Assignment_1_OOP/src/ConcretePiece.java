import java.util.ArrayList;
import java.util.List;

// Modify ConcretePiece class
public abstract class ConcretePiece implements Piece {
    private Player owner;
    private List<Position> movementHistory = new ArrayList<>();

    public ConcretePiece() {
        // The constructor remains parameterless
    }

    // Add a setter method to set the owner after object creation
    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public void addToMovementHistory(Position position) {
        movementHistory.add(position);
    }

    public List<Position> getMovementHistory() {
        return movementHistory;
    }

    @Override
    public Player getOwner() {
        return owner;
    }
}
