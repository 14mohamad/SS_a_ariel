// Modify ConcretePiece class
public abstract class ConcretePiece implements Piece {
    private Player owner;

    public ConcretePiece() {
        // The constructor remains parameterless
    }

    // Add a setter method to set the owner after object creation
    public void setOwner(Player owner) {
        this.owner = owner;
    }

    @Override
    public Player getOwner() {
        return owner;
    }
}
